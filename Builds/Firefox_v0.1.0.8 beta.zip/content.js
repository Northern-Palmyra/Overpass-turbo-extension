var browserObject;
var responceDataType;
var findedNWR;

function logit(...sArgs) {
	//console.log(...sArgs);
}

function browserGet() {
	var navName = "";

	var ua = navigator.userAgent, tem,
		M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
		navName = M[1];
	if (/trident/i.test(M[1])) {
		tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
		navName = 'IE ' + (tem[1] || '');
	}

	return navName.toLowerCase();
}

if (browserGet() == "chrome") {
	browserObject = chrome;
} else {
	browserObject = browser;
}


var manifestData = browserObject.runtime.getManifest();

logit(`
 _______              __   __         ______         __                            
|    |  |.-----.----.|  |_|  |--.    |   __ \\.---.-.|  |.--------.--.--.----.---.-.
|       ||  _  |   _||   _|     |    |    __/|  _  ||  ||        |  |  |   _|  _  |
|__|____||_____|__|  |____|__|__|    |___|   |___._||__||__|__|__|___  |__| |___._|
 StreetView Extension                                            |_____| v `+manifestData.version+`
`);


// inject injected script
var s = document.createElement('script');
s.src = browserObject.runtime.getURL('injected.js');
s.onload = function () {
	this.remove();
};
(document.head || document.documentElement).appendChild(s);
 


function searchInAPIJSON(type, id) {

	logit("Search in API (JSON)");
	logit("type: "+type, "id: "+id);

	var lat = 0;
	var lon = 0;

	for (i=0;i<findedNWR.length;i++) {
		// if popup type and iterate type is equal and popup id equal to iterate id
		if (
			findedNWR[i].type.toLowerCase() == type &&
			findedNWR[i].id == id
		) {
			logit(findedNWR[i]);
			// if iterate has geometry
			if (findedNWR[i].hasOwnProperty('lat') && findedNWR[i].hasOwnProperty('lon')) {
				lat = findedNWR[i].lat;
				lon = findedNWR[i].lon;
			} else if (findedNWR[i].hasOwnProperty('members')) {
				[lat, lon] = searchInAPIJSON(findedNWR[i].members[0].type, findedNWR[i].members[0].ref);
			} else if (findedNWR[i].hasOwnProperty('geometry') && findedNWR[i].geometry[0].hasOwnProperty('lat')) {
				lat = findedNWR[i].geometry[0].lat;
				lon = findedNWR[i].geometry[0].lon;
			} else if (findedNWR[i].hasOwnProperty('center') && findedNWR[i].center.hasOwnProperty('lat')) {
				lat = findedNWR[i].center.lat;
				lon = findedNWR[i].center.lon;
			} else if (findedNWR[i].hasOwnProperty('nodes')) {
				[lat, lon] = searchInAPIJSON("node", findedNWR[i].nodes[0]);
			}
			break;
		}
	}

	return [lat,lon];

}

function searchInAPIXML(type, id){
	logit("Search in API (XML)");
	logit("type: "+type, "id: "+id);

	// find clicked node
	var clickedNode = findedNWR.querySelector('osm '+type+'[id="'+id+'"]');
	if (typeof clickedNode === 'undefined') {
		return [0,0];
	}


	// if type is relation
	if (type == "relation") {
		var relationChild = clickedNode.querySelector("member");
		var type = relationChild.getAttribute("type");
		var id = relationChild.getAttribute("ref");
		[lat, lon] = searchInAPIXML(type, id);
		if (lat!=0 && lon!=0) {
			return [lat,lon];
		}
	}

	// if type is way
	if (type == "way") {
		var wayChild = clickedNode.querySelector("nd");
		var type = "node";
		var id = wayChild.getAttribute("ref");
		[lat, lon] = searchInAPIXML(type, id);
		if (lat!=0 && lon!=0) {
			return [lat,lon];
		}
	}

	// if type is node
	if (type == "node") {
		var node = findedNWR.querySelector('osm '+type+'[id="'+id+'"]');
		var lat = node.getAttribute("lat");
		var lon = node.getAttribute("lon");
		return [lat,lon];
	}

	return [0,0];
}


function searchInUIPopUp(wrapper) {
	var links = wrapper.querySelectorAll("a");

	var lat = 0;
	var lon = 0;

	for (lk=0;lk<links.length;lk++) {
		if (links[lk].getAttribute('href').match("^geo:")) {
			var latLon = links[lk].getAttribute('href').split(":");
			latLon = latLon[1].split(",");
			lat = latLon[0];
			lon = latLon[1];
		}
	}

	return [lat,lon];

}


function makeLinksList(lat,lon) {

	var svUrl = "";

	if (lat==0&&lon==0) {
		svUrl = `<br><br><strong>Unfortunately, the coordinates of this object were not found =(</strong><br><br><a href="`+manifestData.homepage_url+`" target="_blank" data-streetview="true">Send us</a> your request and the approximate coordinates of the map viewport, we will fix this problem soon.`;
	} else {
		var servLinks = [
			{addr: "https://maps.google.com/maps?q=&layer=c&cbll="+lat+","+lon, title: "Google StreetView"},
			{addr: "https://www.instantstreetview.com/@"+lat+","+lon+",242.16h,-2.34p,0z", title: "InstantStreetView"},
			{addr: "https://earth.google.com/web/@"+lat+","+lon+",699.1419278a,7130.84024447d,1y,0h,0t,0r", title: "Google Earth"},
			{addr: "https://yandex.ru/maps/?l=sat%2Cskl&ll="+lon+"%2C"+lat+"&z=18", title: "Yandex Maps"},
			{addr: "https://www.bing.com/maps?cp="+lat+"~"+lon+"&lvl=19.2&style=h", title: "Bing Maps"},
			{addr: "https://mc.bbbike.org/mc/?lon="+lon+"&lat="+lat+"&zoom=22&num=3&mt0=mapnik-german&mt1=cyclemap&mt2=bing-hybrid", title: "Map Compare"},
			{addr: "https://mapchannels.com/quadviewmaps/map.htm?lat="+lat+"&lng="+lon+"", title: "Map Channels"},
			{addr: "https://data.mapchannels.com/dualmaps8/map.htm?lat="+lat+"&lng="+lon+"", title: "Dual Maps"},
			{addr: "https://satellites.pro/Russia_map#"+lat+","+lon+",18", title: "Satellites Pro"},
			{addr: manifestData.homepage_url, title: "<hr>NP Homepage"},
		];

		for (i=0;i<servLinks.length;i++) {
			svUrl += '<br><a href="'+servLinks[i].addr+'" target=_blank data-streetview="true">'+servLinks[i].title+'</a>';
		}
	}

	return svUrl;

}


// on popup show make action
function makeAction() {
	var wrapper = document.querySelector(".leaflet-popup-content");
	if (wrapper==null) {
		return false;
	}

	// if already have links in popup
	if (wrapper.querySelector("a[data-streetview]")) {
		return false;
	}

	var lat = 0;
	var lon = 0;

	// don't use it in this version
	// [lat, lon] = searchInUIPopUp(wrapper);
	
	// if no geo in popup, search in API responce
	if (lat===0&&lon===0) {

		if (responceDataType=="JSON") {
			[lat, lon] = searchInAPIJSON(
				wrapper.querySelector("h4.title span").innerHTML.toLowerCase(),
				wrapper.querySelectorAll("h4.title a")[0].innerHTML
			);
		} else {
			[lat, lon] = searchInAPIXML(
				wrapper.querySelector("h4.title span").innerHTML.toLowerCase(),
				wrapper.querySelectorAll("h4.title a")[0].innerHTML
			);
		}
	}

	var svUrl = makeLinksList(lat,lon);

	wrapper.insertAdjacentHTML("beforeend", svUrl);

	return true;
}


function opHandler() {

	document.querySelector('#map').addEventListener('click', function(e) {
		if (e.target.classList.contains('leaflet-interactive')) {
			setTimeout(() => {
				makeAction();
			}, 500);
		}
	});

}




// receive message from injected script
window.addEventListener('message', function (e) {
    // logit('content script received:' , e.data.type, e.data.data);
	if (e.data.data.slice(0,5)=="<?xml") {
		responceDataType = "XML";
		parser = new DOMParser();
		findedNWR = parser.parseFromString(e.data.data,"text/xml");
	} else {
		responceDataType = "JSON";
		findedNWR = JSON.parse(e.data.data).elements;
	}
	opHandler();
});