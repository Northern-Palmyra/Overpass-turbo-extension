(function (xhr) {

	var XHR = XMLHttpRequest.prototype;

	var open = XHR.open;
	var send = XHR.send;

	XHR.open = function (method, url) {
		this._method = method;
		this._url = url;
		return open.apply(this, arguments);
	};

	XHR.send = function (postData) {
		//console.log('injected script xhr request:', this._method, this._url, this.getAllResponseHeaders(), postData);
		// https://overpass-api.de/api/interpreter
		if (this._url.match(/^https:\/\/overpass-api\.[^\/]*\/api\/interpreter/)) {
			// console.log("CORRECT URL",this._url);
			this.addEventListener('load', function () {
				window.postMessage({ type: 'xhr', data: this.response }, '*');  // send to content script
			});

			// console.log(decodeURI(arguments[0]));

			const re = /\%5Bout%3Ajson%5D/i;
			const found = arguments[0].match(re);
	
			if (found==null) {
				const re2 = /^data=/i;
				const found2 = arguments[0].match(re2);
				if (found2!=null) {
					arguments[0] = arguments[0].replace("data=", "data=[out%3Ajson];");
					
					// document.querySelector("#editor textarea").value = "[out:json]; "+document.querySelector("#editor textarea").value;
					// cm = document.querySelectorAll("#editor .CodeMirror-lines div");
					// cm[cm.length-1].insertAdjacentHTML('afterBegin', '<pre>[<span class="cm-keyword">out</span>:<span class="cm-keyword">json</span>];</pre>');
				}
			}
	
			// console.log(decodeURI(arguments[0]));

		}


		return send.apply(this, arguments);
	};
})(XMLHttpRequest);



const { fetch: origFetch } = window;
window.fetch = async (...args) => {
	const response = await origFetch(...args);
	// console.log('injected script fetch request:', args);
	response
		.clone()
		.blob() // maybe json(), text(), blob()
		.then(data => {
			window.postMessage({ type: 'fetch', data: data }, '*'); // send to content script
			//window.postMessage({ type: 'fetch', data: URL.createObjectURL(data) }, '*'); // if a big media file, can createObjectURL before send to content script
		})
		.catch(err => console.error(err));
	return response;
};