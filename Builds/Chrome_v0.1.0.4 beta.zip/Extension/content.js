var manifestData = chrome.runtime.getManifest();

console.log(`
 _______              __   __         ______         __                            
|    |  |.-----.----.|  |_|  |--.    |   __ \\.---.-.|  |.--------.--.--.----.---.-.
|       ||  _  |   _||   _|     |    |    __/|  _  ||  ||        |  |  |   _|  _  |
|__|____||_____|__|  |____|__|__|    |___|   |___._||__||__|__|__|___  |__| |___._|
 StreetView Extension                                            |_____| v `+manifestData.version+`
`);



// inject injected script
var s = document.createElement('script');
s.src = chrome.runtime.getURL('injected.js');
s.onload = function () {
    this.remove();
};
(document.head || document.documentElement).appendChild(s);
 

// on popup show make action
function makeAction() {
	var wrapper = document.querySelector(".leaflet-popup-content");
	if (wrapper==null) {
		return false;
	}

	if (wrapper.querySelector("a[data-streetview]")) {
		return false;
	}

	var links = wrapper.querySelectorAll("a");
	var lat = 0;
	var lon = 0;
	for (lk=0;lk<links.length;lk++) {
		if (links[lk].getAttribute('href').match("^geo:")) {
			var latLon = links[lk].getAttribute('href').split(":");
			latLon = latLon[1].split(",");
			lat = latLon[0];
			lon = latLon[1];
		}
	}

	// if no geo in popup, search in api responce
	if (lat===0&&lon===0) {

		for (i=0;i<findedNWR.length;i++) {
			if (
				findedNWR[i].type.toLowerCase() == wrapper.querySelector("h4.title span").innerHTML.toLowerCase() &&
				findedNWR[i].id == wrapper.querySelectorAll("h4.title a")[0].innerHTML
			) {
				if (findedNWR[i].hasOwnProperty('geometry')) {
					lat = findedNWR[i].geometry[0].lat;
					lon = findedNWR[i].geometry[0].lon;
				}

				if (findedNWR[i].hasOwnProperty('center')) {
					lat = findedNWR[i].center.lat;
					lon = findedNWR[i].center.lon;
				}

				
				break;
			}
		}
	}

	var svUrl = "";

	var servLinks = [
		{addr: "https://maps.google.com/maps?q=&layer=c&cbll="+lat+","+lon, title: "Google StreetView"},
		{addr: "https://www.instantstreetview.com/@"+lat+","+lon+",242.16h,-2.34p,0z", title: "InstantStreetView"},
		{addr: "https://earth.google.com/web/@"+lat+","+lon+",699.1419278a,7130.84024447d,1y,0h,0t,0r", title: "Google Earth"},
		{addr: "https://yandex.ru/maps/?l=sat%2Cskl&ll="+lon+"%2C"+lat+"&z=18", title: "Yandex Maps"},
		{addr: "https://www.bing.com/maps?cp="+lat+"~"+lon+"&lvl=19.2&style=h", title: "Bing Maps"},
		{addr: "https://mc.bbbike.org/mc/?lon="+lon+"&lat="+lat+"&zoom=22&num=3&mt0=mapnik-german&mt1=cyclemap&mt2=bing-hybrid", title: "Map Compare"},
		{addr: "https://mapchannels.com/quadviewmaps/map.htm?lat="+lat+"&lng="+lon+"", title: "Map Channels"},
		{addr: "https://data.mapchannels.com/dualmaps8/map.htm?lat="+lat+"&lng="+lon+"", title: "Dual Maps"},
		{addr: "https://satellites.pro/Russia_map#"+lat+","+lon+",18", title: "Satellites Pro"},
		{addr: manifestData.homepage_url, title: "<hr>NP Homepage"},
	];

	for (i=0;i<servLinks.length;i++) {
		svUrl += '<br><a href="'+servLinks[i].addr+'" target=_blank data-streetview="true">'+servLinks[i].title+'</a>';
	}

	wrapper.insertAdjacentHTML("beforeend", svUrl);

	return true;
}


function opHandler() {

	document.querySelector('#map').addEventListener('click', function(e) {
		if (e.target.classList.contains('leaflet-interactive')) {
			setTimeout(() => {
				makeAction();
			}, 500);
		}
	});

}


var findedNWR = [];

// receive message from injected script
window.addEventListener('message', function (e) {
    // console.log('content script received:' , e.data.type, e.data.data);
	if (e.data.data.slice(0,5)=="<?xml") {
		console.log("Something wrong with your request. Make sure your request include [out:json] in your first line of request.");
	} else {
		findedNWR = JSON.parse(e.data.data).elements;
		// console.log(findedNWR);
	}
	opHandler();
});