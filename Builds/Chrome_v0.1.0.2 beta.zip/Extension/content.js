console.log(`
 _______              __   __         ______         __                            
|    |  |.-----.----.|  |_|  |--.    |   __ \.---.-.|  |.--------.--.--.----.---.-.
|       ||  _  |   _||   _|     |    |    __/|  _  ||  ||        |  |  |   _|  _  |
|__|____||_____|__|  |____|__|__|    |___|   |___._||__||__|__|__|___  |__| |___._|
		StreetView Extension v0.2								 |_____|           
`);



// inject injected script
var s = document.createElement('script');
s.src = chrome.runtime.getURL('injected.js');
s.onload = function () {
    this.remove();
};
(document.head || document.documentElement).appendChild(s);
 

// on popup show make action
function makeAction() {
	var wrapper = document.querySelector(".leaflet-popup-content");
	if (wrapper==null) {
		return false;
	}

	if (wrapper.querySelector("a[data-streetview]")) {
		return false;
	}

	var links = wrapper.querySelectorAll("a");
	var lat = 0;
	var lon = 0;
	for (lk=0;lk<links.length;lk++) {
		if (links[lk].getAttribute('href').match("^geo:")) {
			var latLon = links[lk].getAttribute('href').split(":");
			latLon = latLon[1].split(",");
			lat = latLon[0];
			lon = latLon[1];
		}
	}

	// if no geo in popup, search in api responce
	if (lat===0&&lon===0) {

		for (i=0;i<findedNWR.length;i++) {
			if (
				findedNWR[i].type.toLowerCase() == wrapper.querySelector("h4.title span").innerHTML.toLowerCase() &&
				findedNWR[i].id == wrapper.querySelectorAll("h4.title a")[0].innerHTML
			) {
				if (findedNWR[i].hasOwnProperty('geometry')) {
					lat = findedNWR[i].geometry[0].lat;
					lon = findedNWR[i].geometry[0].lon;
				}

				if (findedNWR[i].hasOwnProperty('center')) {
					lat = findedNWR[i].center.lat;
					lon = findedNWR[i].center.lon;
				}

				
				break;
			}
		}
	}

	var svLink = "https://maps.google.com/maps?q=&layer=c&cbll="+lat+","+lon;
	var svUrl = '<a href="'+svLink+'" target=_blank data-streetview="true">Google StreetView</a>';


	wrapper.insertAdjacentHTML("beforeend", svUrl);

	return true;
}


function opHandler() {

	document.querySelector('#map').addEventListener('click', function(e) {
		if (e.target.classList.contains('leaflet-interactive')) {
			setTimeout(() => {
				makeAction();
			}, 500);
		}
	});

}


var findedNWR = [];

// receive message from injected script
window.addEventListener('message', function (e) {
    // console.log('content script received:' , e.data.type, e.data.data);
	if (e.data.data.slice(0,5)=="<?xml") {
		alert("You need to add [out:json] at first line of request.\nOverpass-Turbo Google StreetView Extension by North Palmyra.")
	} else {
		findedNWR = JSON.parse(e.data.data).elements;
		console.log(findedNWR);
	}
	opHandler();
});