function opHandler() {

	function makeAction() {
		var wrapper = document.querySelector(".leaflet-popup-content");
		if (wrapper==null) {
			return false;
		}
		var links = wrapper.querySelectorAll("a");
		var lat = 0;
		var lon = 0;
		for (lk=0;lk<links.length;lk++) {
			if (links[lk].getAttribute('href').match("^geo:")) {
				var latLon = links[lk].getAttribute('href').split(":");
				latLon = latLon[1].split(",");
				lat = latLon[0];
				lon = latLon[1];
			}
		}

		if (lat===0&&lon===0) {
			return false;
		}

		var svLink = "https://maps.google.com/maps?q=&layer=c&cbll="+lat+","+lon;
		var svUrl = '<a href="'+svLink+'" target=_blank>Google StreetView</a>';


		wrapper.insertAdjacentHTML("beforeend", svUrl);

		return true;
	}

	var leaflets = document.querySelectorAll("#map .leaflet-interactive");
	
	for (lk=0;lk<leaflets.length;lk++) {
		if (!leaflets[lk].dataset.streetview) {
			leaflets[lk].dataset.streetview = true;
			leaflets[lk].addEventListener("click", function(){
				setTimeout(() => {
					makeAction();
				}, 500);
			});
		};
	}
	if (!window.np_streetview) {
		window.np_streetview=true;
		console.log(`
	 _______              __   __         ______         __                            
	|    |  |.-----.----.|  |_|  |--.    |   __ \.---.-.|  |.--------.--.--.----.---.-.
	|       ||  _  |   _||   _|     |    |    __/|  _  ||  ||        |  |  |   _|  _  |
	|__|____||_____|__|  |____|__|__|    |___|   |___._||__||__|__|__|___  |__| |___._|
			StreetView Extension v0.1								 |_____|           
		`);
	}
}



chrome.action.onClicked.addListener((tab) => {
	if (!tab.url.includes('chrome://')) {
		chrome.scripting.executeScript({
			target: { tabId: tab.id },
			function: opHandler
		});
	}
});